from dataclasses import replace

import meeteval
from meeteval.wer import ErrorRate, combine_error_rates
from meeteval.wer.wer.error_rate import SelfOverlap
from meeteval.wer.wer.orc import OrcErrorRate
from meeteval.wer.wer.time_constrained import get_self_overlap
from meeteval.wer.wer.utils import check_single_filename

import typing

if typing.TYPE_CHECKING:
    from meeteval.io import STM, SegLST
    from meeteval.wer.wer.cp import CPErrorRate

__all__ = [
    'time_constrained_orc_wer',
    'time_constrained_orc_wer_multifile',
]


def time_constrained_orc_wer(
        reference,
        hypothesis,
        collar=0,
        reference_pseudo_word_level_timing='character_based',
        hypothesis_pseudo_word_level_timing='character_based_points',
        hypothesis_sort='segment',
        reference_sort='segment',
):
    """
    The time-constrained version of the ORC-WER (tcORC-WER).

    Special cases where the reference or hypothesis is empty
    >>> time_constrained_orc_wer([], [])
    OrcErrorRate(errors=0, length=0, insertions=0, deletions=0, substitutions=0, assignment=())
    >>> time_constrained_orc_wer([], [{'session_id': 'a', 'start_time': 0, 'end_time': 1, 'words': 'a', 'speaker': 'A'}])
    OrcErrorRate(errors=1, length=0, insertions=1, deletions=0, substitutions=0, hypothesis_self_overlap=SelfOverlap(overlap_rate=0.0, overlap_time=0, total_time=1), assignment=())
    >>> time_constrained_orc_wer([{'session_id': 'a', 'start_time': 0, 'end_time': 1, 'words': 'a', 'speaker': 'A'}], [])
    OrcErrorRate(error_rate=1.0, errors=1, length=1, insertions=0, deletions=1, substitutions=0, reference_self_overlap=SelfOverlap(overlap_rate=0.0, overlap_time=0, total_time=1), assignment=())
    """
    if reference_sort == 'word':
        raise ValueError(
            'reference_sort="word" is not supported for time-constrained '
            'ORC-WER because the ORC-WER assumes that an utterance appears'
            'continuously in the reference.'
        )

    from meeteval.wer.wer.time_constrained import preprocess_time_constrained

    reference, hypothesis, reference_self_overlap, hypothesis_self_overlap = preprocess_time_constrained(
        reference, hypothesis, collar,
        reference_pseudo_word_level_timing, hypothesis_pseudo_word_level_timing,
        hypothesis_sort, reference_sort,
    )

    er = _tcorcwer(reference, hypothesis)
    er = replace(
        er,
        reference_self_overlap=reference_self_overlap,
        hypothesis_self_overlap=hypothesis_self_overlap
    )
    return er


def _tcorcwer(reference, hypothesis):
    """
    The core code of the time-constrained ORC-WER.
    Performs no preprocessing and assumes that the input is already preprocessed.
    """
    hypothesis = hypothesis.groupby('speaker')
    reference = reference.sorted('start_time')  # TODO! This is not correct in general, only for the benchmark!

    # Compute the time-constrained ORC distance
    from meeteval.wer.matching.cy_time_constrained_orc_matching import time_constrained_orc_levenshtein_distance
    distance, assignment = time_constrained_orc_levenshtein_distance(
        [segment.T['words'] for segment in reference.groupby('segment_index').values()],
        [stream.T['words'] for stream in hypothesis.values()],
        [list(zip(segment.T['start_time'], segment.T['end_time'])) for segment in
         reference.groupby('segment_index').values()],
        [list(zip(stream.T['start_time'], stream.T['end_time'])) for stream in hypothesis.values()],
    )

    # Translate the assignment from hypothesis index to stream id
    hypothesis_keys = list(hypothesis.keys())
    assignment = [hypothesis_keys[h] for h in assignment]

    # Apply assignment in seglst format
    r_ = list(reference.groupby('segment_index').values())  # Shallow copy because we pop later
    if assignment:
        reference_new = []
        for h in assignment:
            for w in r_.pop(0):
                reference_new.append({**w, 'speaker': h})
        reference_new = meeteval.io.SegLST(reference_new).groupby('speaker')
    else:
        reference_new = reference.groupby('speaker')

    # Consistency check: Compute WER with the siso algorithm after applying the
    # assignment and compare the result with the distance from the ORC algorithm
    from meeteval.wer.wer.time_constrained import _time_constrained_siso_error_rate
    er = combine_error_rates(*[
        _time_constrained_siso_error_rate(
            reference_new.get(k, meeteval.io.SegLST([])),
            hypothesis.get(k, meeteval.io.SegLST([])),
        )
        for k in set(hypothesis.keys()) | set(reference_new.keys())
    ])
    length = len(reference)
    assert er.length == length, (length, er)
    assert er.errors == distance, (distance, er, assignment)

    return OrcErrorRate(
        er.errors, er.length,
        insertions=er.insertions,
        deletions=er.deletions,
        substitutions=er.substitutions,
        assignment=tuple(assignment),
        reference_self_overlap=None,
        hypothesis_self_overlap=None,
    )


def time_constrained_orc_wer_multifile(
        reference: 'STM', hypothesis: 'STM',
        reference_pseudo_word_level_timing='character_based',
        hypothesis_pseudo_word_level_timing='character_based_points',
        collar: int = 0,
        hypothesis_sort='segment',
        reference_sort='segment',
        partial=False,
) -> 'dict[str, CPErrorRate]':
    from meeteval.io.seglst import apply_multi_file
    r = apply_multi_file(lambda r, h: time_constrained_orc_wer(
        r, h,
        reference_pseudo_word_level_timing=reference_pseudo_word_level_timing,
        hypothesis_pseudo_word_level_timing=hypothesis_pseudo_word_level_timing,
        collar=collar,
        hypothesis_sort=hypothesis_sort,
        reference_sort=reference_sort,
    ), reference, hypothesis, partial=partial)
    return r
